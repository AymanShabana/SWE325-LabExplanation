package com.example.pdf.demo.models;

public enum UserRole {
    USER,
    ADMIN
}
